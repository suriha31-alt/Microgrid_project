package com.example.microgrid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicrogridApplicationTests {

	@Test
	void contextLoads() {
	}

}
