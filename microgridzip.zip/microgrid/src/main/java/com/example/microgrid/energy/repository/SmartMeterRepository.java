package com.example.microgrid.energy.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.SmartMeter;

public interface SmartMeterRepository
        extends JpaRepository<SmartMeter, Long> {

    Optional<SmartMeter> findByMeterNumber(String meterNumber);
} 