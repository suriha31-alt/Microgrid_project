package com.example.microgrid.energy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.Product;
import com.example.microgrid.energy.entity.ProductType;

public interface ProductRepository
        extends JpaRepository<Product, Long> {

    Optional<Product> findByProductCode(
            String productCode);

    List<Product> findByType(ProductType type);

    List<Product> findByActiveTrue();
}