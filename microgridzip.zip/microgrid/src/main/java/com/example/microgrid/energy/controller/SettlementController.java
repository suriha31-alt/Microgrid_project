package com.example.microgrid.energy.controller;

import com.example.microgrid.energy.dto.SettlementRequest;
import com.example.microgrid.energy.dto.SettlementResponse;
import com.example.microgrid.energy.service.SettlementService;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/energy/settlements")
public class SettlementController {

    private final SettlementService settlementService;

    public SettlementController(
            SettlementService settlementService) {

        this.settlementService = settlementService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SettlementResponse createSettlement(
            @RequestBody SettlementRequest request) {

        return settlementService.createSettlement(request);
    }

    @GetMapping("/{id}")
    public SettlementResponse getSettlement(
            @PathVariable Long id) {

        return settlementService.getSettlement(id);
    }

    @GetMapping
    public List<SettlementResponse> getAllSettlements() {

        return settlementService.getAllSettlements();
    }
}