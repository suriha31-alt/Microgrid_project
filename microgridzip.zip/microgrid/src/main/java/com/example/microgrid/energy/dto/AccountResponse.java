package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class AccountResponse {

    private final Long id;
    private final String accountCode;
    private final String accountName;
    private final String type;
    private final String description;
    private final Boolean active;
    private final LocalDateTime createdAt;

    public AccountResponse(
            Long id,
            String accountCode,
            String accountName,
            String type,
            String description,
            Boolean active,
            LocalDateTime createdAt) {

        this.id = id;
        this.accountCode = accountCode;
        this.accountName = accountName;
        this.type = type;
        this.description = description;
        this.active = active;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getAccountCode() {
        return accountCode;
    }

    public String getAccountName() {
        return accountName;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public Boolean getActive() {
        return active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}