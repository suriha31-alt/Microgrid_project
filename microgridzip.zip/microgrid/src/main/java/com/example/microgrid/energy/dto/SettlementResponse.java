package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class SettlementResponse {

    private final Long id;
    private final String settlementNumber;
    private final Long paymentId;
    private final Double energyKwh;
    private final Double amount;
    private final String status;
    private final LocalDateTime settlementDate;

    public SettlementResponse(
            Long id,
            String settlementNumber,
            Long paymentId,
            Double energyKwh,
            Double amount,
            String status,
            LocalDateTime settlementDate) {

        this.id = id;
        this.settlementNumber = settlementNumber;
        this.paymentId = paymentId;
        this.energyKwh = energyKwh;
        this.amount = amount;
        this.status = status;
        this.settlementDate = settlementDate;
    }

    public Long getId() {
        return id;
    }

    public String getSettlementNumber() {
        return settlementNumber;
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public Double getEnergyKwh() {
        return energyKwh;
    }

    public Double getAmount() {
        return amount;
    }

    public String getStatus() {
        return status;
    }

    public LocalDateTime getSettlementDate() {
        return settlementDate;
    }
}