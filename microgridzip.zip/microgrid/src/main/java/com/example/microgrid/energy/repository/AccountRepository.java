package com.example.microgrid.energy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.Account;
import com.example.microgrid.energy.entity.AccountType;

public interface AccountRepository
        extends JpaRepository<Account, Long> {

    Optional<Account> findByAccountCode(
            String accountCode);

    List<Account> findByType(AccountType type);

    List<Account> findByActiveTrue();
}