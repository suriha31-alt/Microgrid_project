package com.example.microgrid.energy.dto;

import com.example.microgrid.energy.entity.AccountType;

public class AccountRequest {

    private String accountCode;
    private String accountName;
    private AccountType type;
    private String description;

    public AccountRequest() {
    }

    public String getAccountCode() {
        return accountCode;
    }

    public void setAccountCode(String accountCode) {
        this.accountCode = accountCode;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public AccountType getType() {
        return type;
    }

    public void setType(AccountType type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}