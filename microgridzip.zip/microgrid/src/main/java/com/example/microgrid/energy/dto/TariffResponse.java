package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class TariffResponse {

    private final Long id;
    private final String type;
    private final Double ratePerKwh;
    private final Double minimumRate;
    private final Double maximumRate;
    private final Boolean active;
    private final LocalDateTime createdAt;

    public TariffResponse(
            Long id,
            String type,
            Double ratePerKwh,
            Double minimumRate,
            Double maximumRate,
            Boolean active,
            LocalDateTime createdAt) {

        this.id = id;
        this.type = type;
        this.ratePerKwh = ratePerKwh;
        this.minimumRate = minimumRate;
        this.maximumRate = maximumRate;
        this.active = active;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public Double getMinimumRate() {
        return minimumRate;
    }

    public Double getMaximumRate() {
        return maximumRate;
    }

    public Boolean getActive() {
        return active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}