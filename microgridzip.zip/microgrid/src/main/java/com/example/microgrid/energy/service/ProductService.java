package com.example.microgrid.energy.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.ProductRequest;
import com.example.microgrid.energy.dto.ProductResponse;
import com.example.microgrid.energy.entity.Product;
import com.example.microgrid.energy.repository.ProductRepository;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public ProductResponse createProduct(
            ProductRequest request) {

        if (request.getProductCode() == null
                || request.getProductCode().isBlank()) {

            throw new RuntimeException(
                    "Product code is required");
        }

        if (request.getProductName() == null
                || request.getProductName().isBlank()) {

            throw new RuntimeException(
                    "Product name is required");
        }

        if (request.getType() == null) {

            throw new RuntimeException(
                    "Product type is required");
        }

        if (request.getUnit() == null
                || request.getUnit().isBlank()) {

            throw new RuntimeException(
                    "Unit is required");
        }

        if (request.getPrice() == null
                || request.getPrice() < 0) {

            throw new RuntimeException(
                    "Price must be zero or greater");
        }

        if (productRepository
                .findByProductCode(
                        request.getProductCode())
                .isPresent()) {

            throw new RuntimeException(
                    "Product code already exists");
        }

        Product product = new Product(
                request.getProductCode(),
                request.getProductName(),
                request.getType(),
                request.getUnit(),
                request.getPrice(),
                request.getDescription(),
                true,
                LocalDateTime.now()
        );

        return convertToResponse(
                productRepository.save(product));
    }

    public List<ProductResponse> getAllProducts() {

        return productRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    public ProductResponse getProduct(Long id) {

        Product product = productRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Product not found"));

        return convertToResponse(product);
    }

    public List<ProductResponse> getProductsByType(
            String type) {

        try {

            return productRepository
                    .findByType(
                            com.example.microgrid.energy.entity
                                    .ProductType
                                    .valueOf(
                                            type.toUpperCase()))
                    .stream()
                    .map(this::convertToResponse)
                    .toList();

        } catch (IllegalArgumentException e) {

            throw new RuntimeException(
                    "Invalid product type");
        }
    }

    public ProductResponse deactivateProduct(
            Long id) {

        Product product = productRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Product not found"));

        product.setActive(false);

        return convertToResponse(
                productRepository.save(product));
    }

    private ProductResponse convertToResponse(
            Product product) {

        return new ProductResponse(
                product.getId(),
                product.getProductCode(),
                product.getProductName(),
                product.getType().name(),
                product.getUnit(),
                product.getPrice(),
                product.getDescription(),
                product.getActive(),
                product.getCreatedAt()
        );
    }
}