package com.example.microgrid.energy.entity;

public enum CustomerInvoiceStatus {

    UNPAID,
    PARTIALLY_PAID,
    PAID,
    CANCELLED
}