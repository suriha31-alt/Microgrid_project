
package com.example.microgrid;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.microgrid.energy.entity.SolarNode;
import com.example.microgrid.energy.repository.SolarNodeRepository;

@Controller
public class DashboardController {

    private final SolarNodeRepository solarNodeRepository;

    public DashboardController(
            SolarNodeRepository solarNodeRepository) {

        this.solarNodeRepository = solarNodeRepository;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {

        // ==============================
        // ADMIN
        // ==============================

        model.addAttribute(
                "adminName",
                "Admin"
        );


        // ==============================
        // CURRENT DATE
        // ==============================

        model.addAttribute(
                "currentDate",
                LocalDate.now().format(
                        DateTimeFormatter.ofPattern("dd MMM yyyy")
                )
        );


        // ==============================
        // SOLAR NODES
        // ==============================

        List<SolarNode> solarNodes =
                solarNodeRepository.findAll();

        model.addAttribute(
                "solarNodes",
                solarNodes
        );


        // ==============================
        // NODE STATISTICS
        // ==============================

        long activeNodes = solarNodes.stream()
                .filter(node ->
                        node.getStatus() != null &&
                        "ACTIVE".equals(
                                node.getStatus().name()
                        )
                )
                .count();

        long totalNodes =
                solarNodes.size();

        long offlineNodes =
                totalNodes - activeNodes;


        double onlinePercentage =
                totalNodes == 0
                        ? 0
                        : (activeNodes * 100.0)
                        / totalNodes;


        model.addAttribute(
                "activeNodeCount",
                activeNodes
        );

        model.addAttribute(
                "offlineNodeCount",
                offlineNodes
        );

        model.addAttribute(
                "onlinePercentage",
                Math.round(onlinePercentage)
        );


        // ==============================
        // DASHBOARD VALUES
        // ==============================
        // These will be connected to your
        // existing telemetry and wallet
        // services in the next step.

        model.addAttribute(
                "solarGeneration",
                0
        );

        model.addAttribute(
                "generationTrend",
                "--"
        );

        model.addAttribute(
                "generationPercentage",
                0
        );

        model.addAttribute(
                "generationCapacityText",
                "Available capacity"
        );


        model.addAttribute(
                "energyConsumed",
                0
        );

        model.addAttribute(
                "consumptionPercentage",
                0
        );


        model.addAttribute(
                "energySurplus",
                0
        );

        model.addAttribute(
                "surplusPercentage",
                0
        );

        model.addAttribute(
                "surplusStatus",
                "Available"
        );


        model.addAttribute(
                "walletBalance",
                0
        );

        model.addAttribute(
                "walletTrend",
                "--"
        );

        model.addAttribute(
                "walletPercentage",
                0
        );


        // ==============================
        // CHART DATA
        // ==============================

        model.addAttribute(
                "generationChartPoints",
                "0,190 100,160 200,140 300,110 400,90 500,60 600,40 700,20"
        );

        model.addAttribute(
                "consumptionChartPoints",
                "0,210 100,190 200,175 300,160 400,145 500,130 600,120 700,110"
        );


        model.addAttribute(
                "chartLabels",
                List.of(
                        "6 AM",
                        "9 AM",
                        "12 PM",
                        "3 PM",
                        "6 PM",
                        "9 PM"
                )
        );


        // ==============================
        // RECENT TRADES
        // ==============================

        model.addAttribute(
                "recentTrades",
                List.of()
        );


        return "dashboard";
    }
}
