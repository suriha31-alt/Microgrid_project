package com.example.microgrid.energy.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "energy_trades")
public class EnergyTrade {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "seller_node_id", nullable = false)
    private SolarNode sellerNode;

    @ManyToOne
    @JoinColumn(name = "buyer_node_id", nullable = false)
    private SolarNode buyerNode;

    @Column(nullable = false)
    private Double energyKwh;

    @Column(nullable = false)
    private Double pricePerKwh;

    @Column(nullable = false)
    private Double totalAmount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TradeStatus status;

    @Column(nullable = false)
    private LocalDateTime tradeTime;

    public EnergyTrade() {
    }

    public EnergyTrade(
            SolarNode sellerNode,
            SolarNode buyerNode,
            Double energyKwh,
            Double pricePerKwh,
            Double totalAmount,
            TradeStatus status,
            LocalDateTime tradeTime) {

        this.sellerNode = sellerNode;
        this.buyerNode = buyerNode;
        this.energyKwh = energyKwh;
        this.pricePerKwh = pricePerKwh;
        this.totalAmount = totalAmount;
        this.status = status;
        this.tradeTime = tradeTime;
    }

    public Long getId() {
        return id;
    }

    public SolarNode getSellerNode() {
        return sellerNode;
    }

    public SolarNode getBuyerNode() {
        return buyerNode;
    }

    public Double getEnergyKwh() {
        return energyKwh;
    }

    public Double getPricePerKwh() {
        return pricePerKwh;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public TradeStatus getStatus() {
        return status;
    }

    public LocalDateTime getTradeTime() {
        return tradeTime;
    }

    public void setStatus(TradeStatus status) {
        this.status = status;
    }
}