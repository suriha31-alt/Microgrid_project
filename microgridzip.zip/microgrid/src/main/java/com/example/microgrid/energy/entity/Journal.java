package com.example.microgrid.energy.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "journals")
public class Journal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String journalCode;

    @Column(nullable = false)
    private String journalName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private JournalType type;

    @Column(nullable = false)
    private Boolean active;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    public Journal() {
    }

    public Journal(
            String journalCode,
            String journalName,
            JournalType type,
            Boolean active,
            LocalDateTime createdAt) {

        this.journalCode = journalCode;
        this.journalName = journalName;
        this.type = type;
        this.active = active;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getJournalCode() {
        return journalCode;
    }

    public String getJournalName() {
        return journalName;
    }

    public JournalType getType() {
        return type;
    }

    public Boolean getActive() {
        return active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}