package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class PaymentResponse {

    private final Long id;
    private final String paymentNumber;
    private final Long invoiceId;
    private final Double amount;
    private final String paymentMethod;
    private final String status;
    private final LocalDateTime paymentDate;

    public PaymentResponse(
            Long id,
            String paymentNumber,
            Long invoiceId,
            Double amount,
            String paymentMethod,
            String status,
            LocalDateTime paymentDate) {

        this.id = id;
        this.paymentNumber = paymentNumber;
        this.invoiceId = invoiceId;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.status = status;
        this.paymentDate = paymentDate;
    }

    public Long getId() {
        return id;
    }

    public String getPaymentNumber() {
        return paymentNumber;
    }

    public Long getInvoiceId() {
        return invoiceId;
    }

    public Double getAmount() {
        return amount;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public String getStatus() {
        return status;
    }

    public LocalDateTime getPaymentDate() {
        return paymentDate;
    }
}