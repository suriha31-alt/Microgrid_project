package com.example.microgrid.energy.dto;

import java.util.List;

import com.example.microgrid.energy.entity.JournalType;

public class JournalRequest {

    private String journalCode;
    private String journalName;
    private JournalType type;

    private List<JournalLineRequest> entries;

    public JournalRequest() {
    }

    public String getJournalCode() {
        return journalCode;
    }

    public void setJournalCode(String journalCode) {
        this.journalCode = journalCode;
    }

    public String getJournalName() {
        return journalName;
    }

    public void setJournalName(String journalName) {
        this.journalName = journalName;
    }

    public JournalType getType() {
        return type;
    }

    public void setType(JournalType type) {
        this.type = type;
    }

    public List<JournalLineRequest> getEntries() {
        return entries;
    }

    public void setEntries(List<JournalLineRequest> entries) {
        this.entries = entries;
    }

    public static class JournalLineRequest {

        private Long accountId;
        private Double debit;
        private  Double credit;
        private  String description;
        private  String referenceNumber;

        public JournalLineRequest() {
        }

        public Long getAccountId() {
            return accountId;
        }

        public void setAccountId(Long accountId) {
            this.accountId = accountId;
        }

        public Double getDebit() {
            return debit;
        }

        public void setDebit(Double debit) {
            this.debit = debit;
        }

        public Double getCredit() {
            return credit;
        }

        public void setCredit(Double credit) {
            this.credit = credit;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getReferenceNumber() {
            return referenceNumber;
        }

        public void setReferenceNumber(String referenceNumber) {
            this.referenceNumber = referenceNumber;
        }
    }
}