package com.example.microgrid.energy.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.Tariff;
import com.example.microgrid.energy.entity.TariffType;

public interface TariffRepository
        extends JpaRepository<Tariff, Long> {

    Optional<Tariff> findByTypeAndActiveTrue(
            TariffType type);
}