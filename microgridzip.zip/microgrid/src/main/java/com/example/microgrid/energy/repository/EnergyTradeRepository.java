package com.example.microgrid.energy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.EnergyTrade;

public interface EnergyTradeRepository
        extends JpaRepository<EnergyTrade, Long> {

    List<EnergyTrade> findBySellerNodeId(Long sellerNodeId);

    List<EnergyTrade> findByBuyerNodeId(Long buyerNodeId);
}