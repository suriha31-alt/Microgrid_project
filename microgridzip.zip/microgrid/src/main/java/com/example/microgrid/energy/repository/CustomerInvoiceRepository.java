package com.example.microgrid.energy.repository;

import com.example.microgrid.energy.entity.CustomerInvoice;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CustomerInvoiceRepository
        extends JpaRepository<CustomerInvoice, Long> {

    Optional<CustomerInvoice> findByInvoiceNumber(
            String invoiceNumber);

    Optional<CustomerInvoice> findBySalesOrderId(
            Long salesOrderId);
}