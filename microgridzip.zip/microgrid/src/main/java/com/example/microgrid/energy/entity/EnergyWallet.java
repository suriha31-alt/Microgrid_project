package com.example.microgrid.energy.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "energy_wallets")
public class EnergyWallet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "solar_node_id", nullable = false, unique = true)
    private SolarNode solarNode;

    @Column(nullable = false)
    private Double availableCredits;

    @Column(nullable = false)
    private Double totalGeneratedKwh;

    @Column(nullable = false)
    private Double totalConsumedKwh;

    public EnergyWallet() {
    }

    public EnergyWallet(
            SolarNode solarNode,
            Double availableCredits,
            Double totalGeneratedKwh,
            Double totalConsumedKwh) {

        this.solarNode = solarNode;
        this.availableCredits = availableCredits;
        this.totalGeneratedKwh = totalGeneratedKwh;
        this.totalConsumedKwh = totalConsumedKwh;
    }

    public Long getId() {
        return id;
    }

    public SolarNode getSolarNode() {
        return solarNode;
    }

    public void setSolarNode(SolarNode solarNode) {
        this.solarNode = solarNode;
    }

    public Double getAvailableCredits() {
        return availableCredits;
    }

    public void setAvailableCredits(Double availableCredits) {
        this.availableCredits = availableCredits;
    }

    public Double getTotalGeneratedKwh() {
        return totalGeneratedKwh;
    }

    public void setTotalGeneratedKwh(Double totalGeneratedKwh) {
        this.totalGeneratedKwh = totalGeneratedKwh;
    }

    public Double getTotalConsumedKwh() {
        return totalConsumedKwh;
    }

    public void setTotalConsumedKwh(Double totalConsumedKwh) {
        this.totalConsumedKwh = totalConsumedKwh;
    }
}