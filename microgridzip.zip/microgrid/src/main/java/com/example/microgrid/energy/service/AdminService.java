package com.example.microgrid.energy.service;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.AdminLoginRequest;
import com.example.microgrid.energy.dto.AdminLoginResponse;
import com.example.microgrid.energy.entity.Admin;
import com.example.microgrid.energy.repository.AdminRepository;

@Service
public class AdminService {

    private final AdminRepository adminRepository;

    public AdminService(AdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

    public Admin createAdmin(
            String username,
            String password) {

        if (adminRepository.findByUsername(username).isPresent()) {
            throw new RuntimeException("Admin username already exists");
        }

        Admin admin = new Admin(
                username,
                password,
                "ADMIN"
        );

        return adminRepository.save(admin);
    }

    public AdminLoginResponse login(
            AdminLoginRequest request) {

        Admin admin = adminRepository
                .findByUsername(request.getUsername())
                .orElseThrow(() ->
                        new RuntimeException("Admin not found"));

        if (!admin.getPassword().equals(request.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        return new AdminLoginResponse(
                "Admin login successful",
                admin.getId(),
                admin.getUsername(),
                admin.getRole()
        );
    }
}