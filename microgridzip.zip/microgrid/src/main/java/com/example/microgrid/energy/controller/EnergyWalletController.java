
package com.example.microgrid.energy.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.EnergyWalletResponse;
import com.example.microgrid.energy.service.EnergyWalletService;

@RestController
@RequestMapping("/api/energy/wallets")
public class EnergyWalletController {

    private final EnergyWalletService service;

    public EnergyWalletController(EnergyWalletService service) {
        this.service = service;
    }

    // Create a wallet for a solar node
    @PostMapping("/{solarNodeId}")
    @ResponseStatus(HttpStatus.CREATED)
    public EnergyWalletResponse createWallet(
            @PathVariable Long solarNodeId) {

        return service.createWallet(solarNodeId);
    }

    // Get wallet details
    @GetMapping("/{solarNodeId}")
    public EnergyWalletResponse getWallet(
            @PathVariable Long solarNodeId) {

        return service.getWallet(solarNodeId);
    }

    // Add energy credits based on generation and consumption
    @PostMapping("/{solarNodeId}/credits")
    public EnergyWalletResponse addCredits(
            @PathVariable Long solarNodeId,
            @RequestParam Double generatedKwh,
            @RequestParam Double consumedKwh) {

        return service.addCredits(
                solarNodeId,
                generatedKwh,
                consumedKwh
        );
    }
}
