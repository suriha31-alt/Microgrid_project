
package com.example.microgrid.energy.service;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.EnergyWalletResponse;
import com.example.microgrid.energy.entity.EnergyWallet;
import com.example.microgrid.energy.entity.SolarNode;
import com.example.microgrid.energy.repository.EnergyWalletRepository;
import com.example.microgrid.energy.repository.SolarNodeRepository;

@Service
public class EnergyWalletService {

    private final EnergyWalletRepository walletRepository;
    private final SolarNodeRepository nodeRepository;

    public EnergyWalletService(
            EnergyWalletRepository walletRepository,
            SolarNodeRepository nodeRepository) {

        this.walletRepository = walletRepository;
        this.nodeRepository = nodeRepository;
    }

    public EnergyWalletResponse createWallet(Long solarNodeId) {

        if (walletRepository
                .findBySolarNodeId(solarNodeId)
                .isPresent()) {

            throw new RuntimeException(
                    "Wallet already exists for this solar node");
        }

        SolarNode node = nodeRepository
                .findById(solarNodeId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Solar node not found"));

        EnergyWallet wallet = new EnergyWallet(
                node,
                0.0,
                0.0,
                0.0
        );

        EnergyWallet savedWallet =
                walletRepository.save(wallet);

        return convertToResponse(savedWallet);
    }

    public EnergyWalletResponse getWallet(Long solarNodeId) {

        EnergyWallet wallet =
                walletRepository
                        .findBySolarNodeId(solarNodeId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Energy wallet not found"));

        return convertToResponse(wallet);
    }

    public EnergyWalletResponse addCredits(
            Long solarNodeId,
            Double generatedKwh,
            Double consumedKwh) {

        EnergyWallet wallet =
                walletRepository
                        .findBySolarNodeId(solarNodeId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Energy wallet not found"));

        double surplus =
                Math.max(
                        generatedKwh - consumedKwh,
                        0
                );

        wallet.setAvailableCredits(
                wallet.getAvailableCredits() + surplus
        );

        wallet.setTotalGeneratedKwh(
                wallet.getTotalGeneratedKwh()
                        + generatedKwh
        );

        wallet.setTotalConsumedKwh(
                wallet.getTotalConsumedKwh()
                        + consumedKwh
        );

        EnergyWallet savedWallet =
                walletRepository.save(wallet);

        return convertToResponse(savedWallet);
    }

    private EnergyWalletResponse convertToResponse(
            EnergyWallet wallet) {

        return new EnergyWalletResponse(
                wallet.getId(),
                wallet.getSolarNode().getId(),
                wallet.getAvailableCredits(),
                wallet.getTotalGeneratedKwh(),
                wallet.getTotalConsumedKwh()
        );
    }
}