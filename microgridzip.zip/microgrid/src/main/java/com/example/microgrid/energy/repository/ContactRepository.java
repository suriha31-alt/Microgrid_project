package com.example.microgrid.energy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.Contact;
import com.example.microgrid.energy.entity.ContactType;

public interface ContactRepository
        extends JpaRepository<Contact, Long> {

    Optional<Contact> findByPhone(String phone);

    List<Contact> findByType(ContactType type);

    List<Contact> findByActiveTrue();
}