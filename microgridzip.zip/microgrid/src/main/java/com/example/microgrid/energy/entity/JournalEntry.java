package com.example.microgrid.energy.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "journal_entries")
public class JournalEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "journal_id")
    private Journal journal;

    @ManyToOne(optional = false)
    @JoinColumn(name = "account_id")
    private Account account;

    @Column(nullable = false)
    private Double debit;

    @Column(nullable = false)
    private Double credit;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private LocalDateTime entryDate;

    @Column(nullable = false)
    private String referenceNumber;

    public JournalEntry() {
    }

    public JournalEntry(
            Journal journal,
            Account account,
            Double debit,
            Double credit,
            String description,
            LocalDateTime entryDate,
            String referenceNumber) {

        this.journal = journal;
        this.account = account;
        this.debit = debit;
        this.credit = credit;
        this.description = description;
        this.entryDate = entryDate;
        this.referenceNumber = referenceNumber;
    }

    public Long getId() {
        return id;
    }

    public Journal getJournal() {
        return journal;
    }

    public Account getAccount() {
        return account;
    }

    public Double getDebit() {
        return debit;
    }

    public Double getCredit() {
        return credit;
    }

    public String getDescription() {
        return description;
    }

    public LocalDateTime getEntryDate() {
        return entryDate;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }
}