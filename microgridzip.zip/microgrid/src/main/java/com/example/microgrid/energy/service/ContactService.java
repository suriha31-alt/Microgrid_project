package com.example.microgrid.energy.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.ContactRequest;
import com.example.microgrid.energy.dto.ContactResponse;
import com.example.microgrid.energy.entity.Contact;
import com.example.microgrid.energy.repository.ContactRepository;

@Service
public class ContactService {

    private final ContactRepository contactRepository;

    public ContactService(ContactRepository contactRepository) {
        this.contactRepository = contactRepository;
    }

    public ContactResponse createContact(
            ContactRequest request) {

        if (request.getName() == null
                || request.getName().isBlank()) {

            throw new RuntimeException(
                    "Contact name is required");
        }

        if (request.getPhone() == null
                || request.getPhone().isBlank()) {

            throw new RuntimeException(
                    "Phone number is required");
        }

        if (request.getType() == null) {

            throw new RuntimeException(
                    "Contact type is required");
        }

        if (contactRepository
                .findByPhone(request.getPhone())
                .isPresent()) {

            throw new RuntimeException(
                    "Contact with this phone already exists");
        }

        Contact contact = new Contact(
                request.getName(),
                request.getPhone(),
                request.getEmail(),
                request.getAddress(),
                request.getType(),
                true,
                LocalDateTime.now()
        );

        return convertToResponse(
                contactRepository.save(contact));
    }

    public List<ContactResponse> getAllContacts() {

        return contactRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    public ContactResponse getContact(Long id) {

        Contact contact = contactRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Contact not found"));

        return convertToResponse(contact);
    }

    public List<ContactResponse> getContactsByType(
            String type) {

        try {

            return contactRepository
                    .findByType(
                            com.example.microgrid.energy.entity
                                    .ContactType
                                    .valueOf(type.toUpperCase()))
                    .stream()
                    .map(this::convertToResponse)
                    .toList();

        } catch (IllegalArgumentException e) {

            throw new RuntimeException(
                    "Invalid contact type");
        }
    }

    public ContactResponse deactivateContact(
            Long id) {

        Contact contact = contactRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Contact not found"));

        contact.setActive(false);

        return convertToResponse(
                contactRepository.save(contact));
    }

    private ContactResponse convertToResponse(
            Contact contact) {

        return new ContactResponse(
                contact.getId(),
                contact.getName(),
                contact.getPhone(),
                contact.getEmail(),
                contact.getAddress(),
                contact.getType().name(),
                contact.getActive(),
                contact.getCreatedAt()
        );
    }
}