package com.example.microgrid.energy.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.Journal;
import com.example.microgrid.energy.entity.JournalType;

public interface JournalRepository
        extends JpaRepository<Journal, Long> {

    Optional<Journal> findByJournalCode(
            String journalCode);

    List<Journal> findByType(JournalType type);

    List<Journal> findByActiveTrue();
}