package com.example.microgrid.energy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.AccountRequest;
import com.example.microgrid.energy.dto.AccountResponse;
import com.example.microgrid.energy.service.AccountService;

@RestController
@RequestMapping("/api/energy/accounts")
public class AccountController {

    private final AccountService service;

    public AccountController(AccountService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public AccountResponse createAccount(
            @RequestBody AccountRequest request) {

        return service.createAccount(request);
    }

    @GetMapping
    public List<AccountResponse> getAllAccounts() {
        return service.getAllAccounts();
    }

    @GetMapping("/{id}")
    public AccountResponse getAccount(
            @PathVariable Long id) {

        return service.getAccount(id);
    }

    @GetMapping("/type/{type}")
    public List<AccountResponse> getAccountsByType(
            @PathVariable String type) {

        return service.getAccountsByType(type);
    }

    @PutMapping("/{id}/deactivate")
    public AccountResponse deactivateAccount(
            @PathVariable Long id) {

        return service.deactivateAccount(id);
    }
}