package com.example.microgrid.energy.entity;

public enum NodeStatus {

    ACTIVE,
    INACTIVE,
    MAINTENANCE
}