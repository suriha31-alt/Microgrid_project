package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class TelemetryResponse {

    private Long id;
    private Long meterId;
    private String meterNumber;
    private LocalDateTime timestamp;

    private Double generationKwh;
    private Double consumptionKwh;
    private Double batteryChargeKwh;
    private Double surplusKwh;
    private Double deficitKwh;

    public TelemetryResponse() {
    }

    public TelemetryResponse(
            Long id,
            Long meterId,
            String meterNumber,
            LocalDateTime timestamp,
            Double generationKwh,
            Double consumptionKwh,
            Double batteryChargeKwh,
            Double surplusKwh,
            Double deficitKwh) {

        this.id = id;
        this.meterId = meterId;
        this.meterNumber = meterNumber;
        this.timestamp = timestamp;
        this.generationKwh = generationKwh;
        this.consumptionKwh = consumptionKwh;
        this.batteryChargeKwh = batteryChargeKwh;
        this.surplusKwh = surplusKwh;
        this.deficitKwh = deficitKwh;
    }

    public Long getId() {
        return id;
    }

    public Long getMeterId() {
        return meterId;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public Double getGenerationKwh() {
        return generationKwh;
    }

    public Double getConsumptionKwh() {
        return consumptionKwh;
    }

    public Double getBatteryChargeKwh() {
        return batteryChargeKwh;
    }

    public Double getSurplusKwh() {
        return surplusKwh;
    }

    public Double getDeficitKwh() {
        return deficitKwh;
    }
}