package com.example.microgrid.energy.entity;

public enum JournalType {

    SALES,
    PURCHASE,
    BANK,
    ENERGY_CREDIT
}