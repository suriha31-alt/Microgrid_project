package com.example.microgrid.energy.controller;

import com.example.microgrid.energy.dto.SalesOrderRequest;
import com.example.microgrid.energy.dto.SalesOrderResponse;
import com.example.microgrid.energy.service.SalesOrderService;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/energy/sales-orders")
public class SalesOrderController {

    private final SalesOrderService service;

    public SalesOrderController(
            SalesOrderService service) {

        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SalesOrderResponse createOrder(
            @RequestBody SalesOrderRequest request) {

        return service.createOrder(request);
    }

    @GetMapping("/{id}")
    public SalesOrderResponse getOrder(
            @PathVariable Long id) {

        return service.getOrder(id);
    }

    @GetMapping
    public List<SalesOrderResponse> getAllOrders() {

        return service.getAllOrders();
    }
}