package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

public class TelemetryRequest {

    @NotNull(message = "Meter ID is required")
    private Long meterId;

    @NotNull(message = "Timestamp is required")
    private LocalDateTime timestamp;

    @NotNull(message = "Generation is required")
    @PositiveOrZero(message = "Generation cannot be negative")
    private Double generationKwh;

    @NotNull(message = "Consumption is required")
    @PositiveOrZero(message = "Consumption cannot be negative")
    private Double consumptionKwh;

    @NotNull(message = "Battery charge is required")
    @PositiveOrZero(message = "Battery charge cannot be negative")
    private Double batteryChargeKwh;

    public TelemetryRequest() {
    }

    public Long getMeterId() {
        return meterId;
    }

    public void setMeterId(Long meterId) {
        this.meterId = meterId;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public Double getGenerationKwh() {
        return generationKwh;
    }

    public void setGenerationKwh(Double generationKwh) {
        this.generationKwh = generationKwh;
    }

    public Double getConsumptionKwh() {
        return consumptionKwh;
    }

    public void setConsumptionKwh(Double consumptionKwh) {
        this.consumptionKwh = consumptionKwh;
    }

    public Double getBatteryChargeKwh() {
        return batteryChargeKwh;
    }

    public void setBatteryChargeKwh(Double batteryChargeKwh) {
        this.batteryChargeKwh = batteryChargeKwh;
    }
}