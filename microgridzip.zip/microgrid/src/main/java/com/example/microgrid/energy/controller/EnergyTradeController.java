package com.example.microgrid.energy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.EnergyTradeRequest;
import com.example.microgrid.energy.dto.EnergyTradeResponse;
import com.example.microgrid.energy.service.EnergyTradeService;

@RestController
@RequestMapping("/api/energy/trades")
public class EnergyTradeController {

    private final EnergyTradeService service;

    public EnergyTradeController(
            EnergyTradeService service) {

        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EnergyTradeResponse createTrade(
            @RequestBody EnergyTradeRequest request) {

        return service.createTrade(request);
    }

    @GetMapping
    public List<EnergyTradeResponse> getAllTrades() {

        return service.getAllTrades();
    }

    @GetMapping("/seller/{sellerNodeId}")
    public List<EnergyTradeResponse> getSellerTrades(
            @PathVariable Long sellerNodeId) {

        return service.getSellerTrades(sellerNodeId);
    }

    @GetMapping("/buyer/{buyerNodeId}")
    public List<EnergyTradeResponse> getBuyerTrades(
            @PathVariable Long buyerNodeId) {

        return service.getBuyerTrades(buyerNodeId);
    }
}