package com.example.microgrid.energy.repository;

import com.example.microgrid.energy.entity.Settlement;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SettlementRepository
        extends JpaRepository<Settlement, Long> {

    Optional<Settlement> findBySettlementNumber(
            String settlementNumber);

    boolean existsBySettlementNumber(
            String settlementNumber);
}