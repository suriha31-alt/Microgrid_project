package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class ContactResponse {

    private final Long id;
    private final String name;
    private final String phone;
    private final String email;
    private final String address;
    private final String type;
    private final Boolean active;
    private final LocalDateTime createdAt;

    public ContactResponse(
            Long id,
            String name,
            String phone,
            String email,
            String address,
            String type,
            Boolean active,
            LocalDateTime createdAt) {

        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.type = type;
        this.active = active;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getType() {
        return type;
    }

    public Boolean getActive() {
        return active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}