package com.example.microgrid.energy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.SolarNodeRequest;
import com.example.microgrid.energy.dto.SolarNodeResponse;
import com.example.microgrid.energy.service.SolarNodeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/energy/nodes")
public class SolarNodeController {

    private final SolarNodeService service;

    public SolarNodeController(SolarNodeService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SolarNodeResponse createNode(
            @Valid @RequestBody SolarNodeRequest request) {

        return service.createNode(request);
    }

    @GetMapping
    public List<SolarNodeResponse> getAllNodes() {

        return service.getAllNodes();
    }

    @GetMapping("/{id}")
    public SolarNodeResponse getNodeById(
            @PathVariable Long id) {

        return service.getNodeById(id);
    }
}