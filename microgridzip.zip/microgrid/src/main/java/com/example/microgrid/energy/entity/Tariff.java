package com.example.microgrid.energy.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "energy_tariffs")
public class Tariff {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TariffType type;

    @Column(nullable = false)
    private Double ratePerKwh;

    @Column(nullable = false)
    private Double minimumRate;

    @Column(nullable = false)
    private Double maximumRate;

    @Column(nullable = false)
    private Boolean active;

    @Column(nullable = false)
    private LocalDateTime createdAt;

    public Tariff() {
    }

    public Tariff(
            TariffType type,
            Double ratePerKwh,
            Double minimumRate,
            Double maximumRate,
            Boolean active,
            LocalDateTime createdAt) {

        this.type = type;
        this.ratePerKwh = ratePerKwh;
        this.minimumRate = minimumRate;
        this.maximumRate = maximumRate;
        this.active = active;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public TariffType getType() {
        return type;
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public Double getMinimumRate() {
        return minimumRate;
    }

    public Double getMaximumRate() {
        return maximumRate;
    }

    public Boolean getActive() {
        return active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setRatePerKwh(Double ratePerKwh) {
        this.ratePerKwh = ratePerKwh;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
}