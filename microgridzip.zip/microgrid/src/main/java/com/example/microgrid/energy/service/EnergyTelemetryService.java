package com.example.microgrid.energy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.TelemetryRequest;
import com.example.microgrid.energy.dto.TelemetryResponse;
import com.example.microgrid.energy.entity.EnergyTelemetry;
import com.example.microgrid.energy.entity.SmartMeter;
import com.example.microgrid.energy.repository.EnergyTelemetryRepository;
import com.example.microgrid.energy.repository.SmartMeterRepository;

@Service
public class EnergyTelemetryService {

    private final EnergyTelemetryRepository telemetryRepository;
    private final SmartMeterRepository meterRepository;

    public EnergyTelemetryService(
            EnergyTelemetryRepository telemetryRepository,
            SmartMeterRepository meterRepository) {

        this.telemetryRepository = telemetryRepository;
        this.meterRepository = meterRepository;
    }

    public TelemetryResponse recordTelemetry(
            TelemetryRequest request) {

        SmartMeter meter = meterRepository
                .findById(request.getMeterId())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Smart meter not found"));

        double generation = request.getGenerationKwh();
        double consumption = request.getConsumptionKwh();

        /*
         * If generation is greater than consumption,
         * the prosumer has surplus energy.
         *
         * If consumption is greater than generation,
         * the prosumer has an energy deficit.
         */

        double surplus = Math.max(
                generation - consumption, 0);

        double deficit = Math.max(
                consumption - generation, 0);

        EnergyTelemetry telemetry =
                new EnergyTelemetry(
                        meter,
                        request.getTimestamp(),
                        generation,
                        consumption,
                        request.getBatteryChargeKwh(),
                        surplus,
                        deficit
                );

        EnergyTelemetry saved =
                telemetryRepository.save(telemetry);

        return convertToResponse(saved);
    }

    public List<TelemetryResponse> getAllTelemetry() {

        return telemetryRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    public List<TelemetryResponse> getTelemetryByMeter(
            Long meterId) {

        return telemetryRepository
                .findByMeterId(meterId)
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    private TelemetryResponse convertToResponse(
            EnergyTelemetry telemetry) {

        return new TelemetryResponse(
                telemetry.getId(),
                telemetry.getMeter().getId(),
                telemetry.getMeter().getMeterNumber(),
                telemetry.getTimestamp(),
                telemetry.getGenerationKwh(),
                telemetry.getConsumptionKwh(),
                telemetry.getBatteryChargeKwh(),
                telemetry.getSurplusKwh(),
                telemetry.getDeficitKwh()
        );
    }
}