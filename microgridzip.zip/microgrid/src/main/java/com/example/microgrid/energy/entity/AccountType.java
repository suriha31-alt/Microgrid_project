package com.example.microgrid.energy.entity;

public enum AccountType {

    ASSET,
    LIABILITY,
    INCOME,
    EXPENSE
}