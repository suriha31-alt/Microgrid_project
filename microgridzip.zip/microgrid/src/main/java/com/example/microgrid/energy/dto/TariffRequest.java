package com.example.microgrid.energy.dto;

import com.example.microgrid.energy.entity.TariffType;

public class TariffRequest {

    private TariffType type;
    private Double ratePerKwh;
    private Double minimumRate;
    private Double maximumRate;

    public TariffRequest() {
    }

    public TariffType getType() {
        return type;
    }

    public void setType(TariffType type) {
        this.type = type;
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public void setRatePerKwh(Double ratePerKwh) {
        this.ratePerKwh = ratePerKwh;
    }

    public Double getMinimumRate() {
        return minimumRate;
    }

    public void setMinimumRate(Double minimumRate) {
        this.minimumRate = minimumRate;
    }

    public Double getMaximumRate() {
        return maximumRate;
    }

    public void setMaximumRate(Double maximumRate) {
        this.maximumRate = maximumRate;
    }
}