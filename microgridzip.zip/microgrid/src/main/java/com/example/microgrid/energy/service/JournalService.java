
package com.example.microgrid.energy.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.microgrid.energy.dto.JournalEntryResponse;
import com.example.microgrid.energy.dto.JournalRequest;
import com.example.microgrid.energy.entity.Account;
import com.example.microgrid.energy.entity.Journal;
import com.example.microgrid.energy.entity.JournalEntry;
import com.example.microgrid.energy.repository.AccountRepository;
import com.example.microgrid.energy.repository.JournalEntryRepository;
import com.example.microgrid.energy.repository.JournalRepository;

@Service
public class JournalService {

    private final JournalRepository journalRepository;
    private final JournalEntryRepository entryRepository;
    private final AccountRepository accountRepository;

    public JournalService(
            JournalRepository journalRepository,
            JournalEntryRepository entryRepository,
            AccountRepository accountRepository) {

        this.journalRepository = journalRepository;
        this.entryRepository = entryRepository;
        this.accountRepository = accountRepository;
    }

    @Transactional
    public List<JournalEntryResponse> createJournal(
            JournalRequest request) {

        // ==========================================
        // 1. Validate request
        // ==========================================

        if (request == null) {
            throw new RuntimeException(
                    "Journal request cannot be null");
        }

        if (request.getJournalCode() == null
                || request.getJournalCode().isBlank()) {

            throw new RuntimeException(
                    "Journal code is required");
        }

        if (request.getJournalName() == null
                || request.getJournalName().isBlank()) {

            throw new RuntimeException(
                    "Journal name is required");
        }

        if (request.getType() == null) {

            throw new RuntimeException(
                    "Journal type is required");
        }

        // ==========================================
        // 2. Validate journal lines
        // ==========================================

        if (request.getEntries() == null
                || request.getEntries().size() < 2) {

            throw new RuntimeException(
                    "At least two journal lines are required");
        }

        // ==========================================
        // 3. Check duplicate journal code
        // ==========================================

        if (journalRepository
                .findByJournalCode(request.getJournalCode())
                .isPresent()) {

            throw new RuntimeException(
                    "Journal code already exists: "
                            + request.getJournalCode());
        }

        // ==========================================
        // 4. Validate journal lines and totals
        // ==========================================

        double totalDebit = 0.0;
        double totalCredit = 0.0;

        for (JournalRequest.JournalLineRequest line
                : request.getEntries()) {

            if (line == null) {

                throw new RuntimeException(
                        "Journal line cannot be null");
            }

            if (line.getAccountId() == null) {

                throw new RuntimeException(
                        "Account ID is required for every journal line");
            }

            Double debitValue = line.getDebit();
            Double creditValue = line.getCredit();

            double debit = toDouble(debitValue);
            double credit = toDouble(creditValue);

            // Negative amount check
            if (debit < 0.0 || credit < 0.0) {

                throw new RuntimeException(
                        "Debit and credit cannot be negative");
            }

            // Both debit and credit cannot be present
            if (debit > 0.0 && credit > 0.0) {

                throw new RuntimeException(
                        "A journal line cannot contain both debit and credit");
            }

            // At least one amount is required
            if (debit == 0.0 && credit == 0.0) {

                throw new RuntimeException(
                        "Journal line must contain debit or credit");
            }

            totalDebit += debit;
            totalCredit += credit;
        }

        // ==========================================
        // 5. Double-entry validation
        // ==========================================

        if (Math.abs(totalDebit - totalCredit) > 0.001) {

            throw new RuntimeException(
                    "Journal is not balanced. Total debit = "
                            + totalDebit
                            + ", Total credit = "
                            + totalCredit);
        }

        // ==========================================
        // 6. Validate all accounts
        // ==========================================

        List<Account> accounts = new ArrayList<>();

        for (JournalRequest.JournalLineRequest line
                : request.getEntries()) {

            Account account = accountRepository
                    .findById(line.getAccountId())
                    .orElseThrow(() ->
                            new RuntimeException(
                                    "Account not found with ID: "
                                            + line.getAccountId()));

            if (Boolean.FALSE.equals(account.getActive())) {

                throw new RuntimeException(
                        "Account is inactive: "
                                + account.getAccountCode());
            }

            accounts.add(account);
        }

        // ==========================================
        // 7. Create journal
        // ==========================================

        Journal journal = new Journal(
                request.getJournalCode(),
                request.getJournalName(),
                request.getType(),
                true,
                LocalDateTime.now()
        );

        journal = journalRepository.save(journal);

        // ==========================================
        // 8. Create journal entries
        // ==========================================

        List<JournalEntry> entries = new ArrayList<>();

        for (int i = 0;
                i < request.getEntries().size();
                i++) {

            JournalRequest.JournalLineRequest line =
                    request.getEntries().get(i);

            Account account = accounts.get(i);

            Double debitValue = line.getDebit();
            Double creditValue = line.getCredit();

            double debit = toDouble(debitValue);
            double credit = toDouble(creditValue);

            JournalEntry entry = new JournalEntry(
                    journal,
                    account,
                    debit,
                    credit,
                    line.getDescription(),
                    LocalDateTime.now(),
                    line.getReferenceNumber()
            );

            entries.add(entry);
        }

        // ==========================================
        // 9. Save entries
        // ==========================================

        List<JournalEntry> savedEntries =
                entryRepository.saveAll(entries);

        // ==========================================
        // 10. Convert response
        // ==========================================

        return savedEntries
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    // ==============================================
    // Get journal entries
    // ==============================================

    public List<JournalEntryResponse> getJournalEntries(
            Long journalId) {

        if (journalId == null) {

            throw new RuntimeException(
                    "Journal ID is required");
        }

        return entryRepository
                .findByJournalId(journalId)
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    // ==============================================
    // Get account entries
    // ==============================================

    public List<JournalEntryResponse> getAccountEntries(
            Long accountId) {

        if (accountId == null) {

            throw new RuntimeException(
                    "Account ID is required");
        }

        return entryRepository
                .findByAccountId(accountId)
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    // ==============================================
    // Get entries by reference
    // ==============================================

    public List<JournalEntryResponse> getEntriesByReference(
            String referenceNumber) {

        if (referenceNumber == null
                || referenceNumber.isBlank()) {

            throw new RuntimeException(
                    "Reference number is required");
        }

        return entryRepository
                .findByReferenceNumber(referenceNumber)
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    // ==============================================
    // Null-safe Double conversion
    // ==============================================

    private double toDouble(Double value) {

        if (value == null) {
            return 0.0;
        }

        return value.doubleValue();
    }

    // ==============================================
    // Entity -> Response DTO
    // ==============================================

    private JournalEntryResponse convertToResponse(
            JournalEntry entry) {

        return new JournalEntryResponse(
                entry.getId(),
                entry.getJournal().getId(),
                entry.getJournal().getJournalCode(),
                entry.getAccount().getId(),
                entry.getAccount().getAccountCode(),
                entry.getAccount().getAccountName(),
                entry.getDebit(),
                entry.getCredit(),
                entry.getDescription(),
                entry.getReferenceNumber(),
                entry.getEntryDate()
        );
    }
}
