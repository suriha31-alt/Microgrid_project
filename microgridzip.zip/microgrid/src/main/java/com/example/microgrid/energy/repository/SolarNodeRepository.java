package com.example.microgrid.energy.repository;

import com.example.microgrid.energy.entity.SolarNode;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SolarNodeRepository
        extends JpaRepository<SolarNode, Long> {

    Optional<SolarNode> findByNodeCode(String nodeCode);
}