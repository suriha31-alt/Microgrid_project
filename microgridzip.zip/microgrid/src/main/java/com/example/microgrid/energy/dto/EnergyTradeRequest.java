package com.example.microgrid.energy.dto;

public class EnergyTradeRequest {

    private Long sellerNodeId;
    private Long buyerNodeId;
    private Double energyKwh;
    private Double pricePerKwh;

    public EnergyTradeRequest() {
    }

    public Long getSellerNodeId() {
        return sellerNodeId;
    }

    public void setSellerNodeId(Long sellerNodeId) {
        this.sellerNodeId = sellerNodeId;
    }

    public Long getBuyerNodeId() {
        return buyerNodeId;
    }

    public void setBuyerNodeId(Long buyerNodeId) {
        this.buyerNodeId = buyerNodeId;
    }

    public Double getEnergyKwh() {
        return energyKwh;
    }

    public void setEnergyKwh(Double energyKwh) {
        this.energyKwh = energyKwh;
    }

    public Double getPricePerKwh() {
        return pricePerKwh;
    }

    public void setPricePerKwh(Double pricePerKwh) {
        this.pricePerKwh = pricePerKwh;
    }
}