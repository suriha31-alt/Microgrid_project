package com.example.microgrid.energy.dto;

public class AdminLoginResponse {

    private final  String message;
    private final Long adminId;
    private final String username;
    private final String role;

    public AdminLoginResponse(
            String message,
            Long adminId,
            String username,
            String role) {

        this.message = message;
        this.adminId = adminId;
        this.username = username;
        this.role = role;
    }

    public String getMessage() {
        return message;
    }

    public Long getAdminId() {
        return adminId;
    }

    public String getUsername() {
        return username;
    }

    public String getRole() {
        return role;
    }
}