package com.example.microgrid.energy.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "smart_meters")
public class SmartMeter {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String meterNumber;

    @Column(nullable = false)
    private String meterType;

    @ManyToOne
    @JoinColumn(name = "solar_node_id", nullable = false)
    private SolarNode solarNode;

    @Enumerated(EnumType.STRING)
    private MeterStatus status;

    public SmartMeter() {
    }

    public SmartMeter(
            String meterNumber,
            String meterType,
            SolarNode solarNode,
            MeterStatus status) {

        this.meterNumber = meterNumber;
        this.meterType = meterType;
        this.solarNode = solarNode;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }

    public String getMeterType() {
        return meterType;
    }

    public void setMeterType(String meterType) {
        this.meterType = meterType;
    }

    public SolarNode getSolarNode() {
        return solarNode;
    }

    public void setSolarNode(SolarNode solarNode) {
        this.solarNode = solarNode;
    }

    public MeterStatus getStatus() {
        return status;
    }

    public void setStatus(MeterStatus status) {
        this.status = status;
    }
}