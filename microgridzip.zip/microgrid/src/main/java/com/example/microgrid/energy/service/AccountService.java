package com.example.microgrid.energy.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.AccountRequest;
import com.example.microgrid.energy.dto.AccountResponse;
import com.example.microgrid.energy.entity.Account;
import com.example.microgrid.energy.entity.AccountType;
import com.example.microgrid.energy.repository.AccountRepository;

@Service
public class AccountService {

    private final AccountRepository accountRepository;

    public AccountService(
            AccountRepository accountRepository) {

        this.accountRepository = accountRepository;
    }

    public AccountResponse createAccount(
            AccountRequest request) {

        if (request.getAccountCode() == null
                || request.getAccountCode().isBlank()) {

            throw new RuntimeException(
                    "Account code is required");
        }

        if (request.getAccountName() == null
                || request.getAccountName().isBlank()) {

            throw new RuntimeException(
                    "Account name is required");
        }

        if (request.getType() == null) {

            throw new RuntimeException(
                    "Account type is required");
        }

        if (accountRepository
                .findByAccountCode(
                        request.getAccountCode())
                .isPresent()) {

            throw new RuntimeException(
                    "Account code already exists");
        }

        Account account = new Account(
                request.getAccountCode(),
                request.getAccountName(),
                request.getType(),
                request.getDescription(),
                true,
                LocalDateTime.now()
        );

        return convertToResponse(
                accountRepository.save(account));
    }

    public List<AccountResponse> getAllAccounts() {

        return accountRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    public AccountResponse getAccount(Long id) {

        Account account = accountRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Account not found"));

        return convertToResponse(account);
    }

    public List<AccountResponse> getAccountsByType(
            String type) {

        try {

            AccountType accountType =
                    AccountType.valueOf(
                            type.toUpperCase());

            return accountRepository
                    .findByType(accountType)
                    .stream()
                    .map(this::convertToResponse)
                    .toList();

        } catch (IllegalArgumentException e) {

            throw new RuntimeException(
                    "Invalid account type. Use ASSET, LIABILITY, INCOME or EXPENSE");
        }
    }

    public AccountResponse deactivateAccount(
            Long id) {

        Account account = accountRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Account not found"));

        account.setActive(false);

        return convertToResponse(
                accountRepository.save(account));
    }

    private AccountResponse convertToResponse(
            Account account) {

        return new AccountResponse(
                account.getId(),
                account.getAccountCode(),
                account.getAccountName(),
                account.getType().name(),
                account.getDescription(),
                account.getActive(),
                account.getCreatedAt()
        );
    }
}