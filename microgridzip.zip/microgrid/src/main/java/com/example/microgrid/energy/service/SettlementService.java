package com.example.microgrid.energy.service;

import com.example.microgrid.energy.dto.SettlementRequest;
import com.example.microgrid.energy.dto.SettlementResponse;
import com.example.microgrid.energy.entity.Settlement;
import com.example.microgrid.energy.repository.SettlementRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SettlementService {

    private final SettlementRepository settlementRepository;

    public SettlementService(
            SettlementRepository settlementRepository) {

        this.settlementRepository = settlementRepository;
    }

    public SettlementResponse createSettlement(
            SettlementRequest request) {

        if (settlementRepository.existsBySettlementNumber(
                request.getSettlementNumber())) {

            throw new RuntimeException(
                    "Settlement number already exists");
        }

        if (request.getEnergyKwh() == null ||
                request.getEnergyKwh() <= 0) {

            throw new RuntimeException(
                    "Energy must be greater than zero");
        }

        if (request.getAmount() == null ||
                request.getAmount() <= 0) {

            throw new RuntimeException(
                    "Amount must be greater than zero");
        }

        Settlement settlement = new Settlement(
                request.getSettlementNumber(),
                request.getPaymentId(),
                request.getEnergyKwh(),
                request.getAmount(),
                "SETTLED",
                LocalDateTime.now()
        );

        return convertToResponse(
                settlementRepository.save(settlement));
    }

    public SettlementResponse getSettlement(Long id) {

        Settlement settlement = settlementRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Settlement not found"));

        return convertToResponse(settlement);
    }

    public List<SettlementResponse> getAllSettlements() {

        return settlementRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    private SettlementResponse convertToResponse(
            Settlement settlement) {

        return new SettlementResponse(
                settlement.getId(),
                settlement.getSettlementNumber(),
                settlement.getPaymentId(),
                settlement.getEnergyKwh(),
                settlement.getAmount(),
                settlement.getStatus(),
                settlement.getSettlementDate()
        );
    }
}