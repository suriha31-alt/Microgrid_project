package com.example.microgrid.energy.dto;

public class EnergyWalletResponse {

    private Long walletId;
    private Long solarNodeId;
    private Double availableCredits;
    private Double totalGeneratedKwh;
    private Double totalConsumedKwh;

    public EnergyWalletResponse(
            Long walletId,
            Long solarNodeId,
            Double availableCredits,
            Double totalGeneratedKwh,
            Double totalConsumedKwh) {

        this.walletId = walletId;
        this.solarNodeId = solarNodeId;
        this.availableCredits = availableCredits;
        this.totalGeneratedKwh = totalGeneratedKwh;
        this.totalConsumedKwh = totalConsumedKwh;
    }

    public Long getWalletId() {
        return walletId;
    }

    public Long getSolarNodeId() {
        return solarNodeId;
    }

    public Double getAvailableCredits() {
        return availableCredits;
    }

    public Double getTotalGeneratedKwh() {
        return totalGeneratedKwh;
    }

    public Double getTotalConsumedKwh() {
        return totalConsumedKwh;
    }
}