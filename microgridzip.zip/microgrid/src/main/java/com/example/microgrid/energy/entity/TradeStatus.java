package com.example.microgrid.energy.entity;

public enum TradeStatus {

    PENDING,
    COMPLETED,
    CANCELLED
}