package com.example.microgrid.energy.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.microgrid.energy.dto.EnergyTradeRequest;
import com.example.microgrid.energy.dto.EnergyTradeResponse;
import com.example.microgrid.energy.entity.EnergyTrade;
import com.example.microgrid.energy.entity.EnergyWallet;
import com.example.microgrid.energy.entity.SolarNode;
import com.example.microgrid.energy.entity.TradeStatus;
import com.example.microgrid.energy.repository.EnergyTradeRepository;
import com.example.microgrid.energy.repository.EnergyWalletRepository;
import com.example.microgrid.energy.repository.SolarNodeRepository;

@Service
public class EnergyTradeService {

    private final EnergyTradeRepository tradeRepository;
    private final EnergyWalletRepository walletRepository;
    private final SolarNodeRepository nodeRepository;

    public EnergyTradeService(
            EnergyTradeRepository tradeRepository,
            EnergyWalletRepository walletRepository,
            SolarNodeRepository nodeRepository) {

        this.tradeRepository = tradeRepository;
        this.walletRepository = walletRepository;
        this.nodeRepository = nodeRepository;
    }

    @Transactional
    public EnergyTradeResponse createTrade(
            EnergyTradeRequest request) {

        if (request.getSellerNodeId()
                .equals(request.getBuyerNodeId())) {

            throw new RuntimeException(
                    "Seller and buyer cannot be the same solar node");
        }

        if (request.getEnergyKwh() == null
                || request.getEnergyKwh() <= 0) {

            throw new RuntimeException(
                    "Energy amount must be greater than zero");
        }

        if (request.getPricePerKwh() == null
                || request.getPricePerKwh() < 0) {

            throw new RuntimeException(
                    "Price per kWh cannot be negative");
        }

        SolarNode seller = nodeRepository
                .findById(request.getSellerNodeId())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Seller solar node not found"));

        SolarNode buyer = nodeRepository
                .findById(request.getBuyerNodeId())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Buyer solar node not found"));

        EnergyWallet sellerWallet =
                walletRepository
                        .findBySolarNodeId(
                                request.getSellerNodeId())
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Seller wallet not found"));

        EnergyWallet buyerWallet =
                walletRepository
                        .findBySolarNodeId(
                                request.getBuyerNodeId())
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Buyer wallet not found"));

        if (sellerWallet.getAvailableCredits()
                < request.getEnergyKwh()) {

            throw new RuntimeException(
                    "Seller does not have enough energy credits");
        }

        sellerWallet.setAvailableCredits(
                sellerWallet.getAvailableCredits()
                        - request.getEnergyKwh());

        buyerWallet.setAvailableCredits(
                buyerWallet.getAvailableCredits()
                        + request.getEnergyKwh());

        walletRepository.save(sellerWallet);
        walletRepository.save(buyerWallet);

        Double totalAmount =
                request.getEnergyKwh()
                        * request.getPricePerKwh();

        EnergyTrade trade = new EnergyTrade(
                seller,
                buyer,
                request.getEnergyKwh(),
                request.getPricePerKwh(),
                totalAmount,
                TradeStatus.COMPLETED,
                LocalDateTime.now()
        );

        return convertToResponse(
                tradeRepository.save(trade));
    }

    public List<EnergyTradeResponse> getAllTrades() {

        return tradeRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    public List<EnergyTradeResponse> getSellerTrades(
            Long sellerNodeId) {

        return tradeRepository
                .findBySellerNodeId(sellerNodeId)
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    public List<EnergyTradeResponse> getBuyerTrades(
            Long buyerNodeId) {

        return tradeRepository
                .findByBuyerNodeId(buyerNodeId)
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    private EnergyTradeResponse convertToResponse(
            EnergyTrade trade) {

        return new EnergyTradeResponse(
                trade.getId(),
                trade.getSellerNode().getId(),
                trade.getBuyerNode().getId(),
                trade.getEnergyKwh(),
                trade.getPricePerKwh(),
                trade.getTotalAmount(),
                trade.getStatus().name(),
                trade.getTradeTime()
        );
    }
}