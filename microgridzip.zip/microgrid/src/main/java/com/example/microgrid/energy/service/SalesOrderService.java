package com.example.microgrid.energy.service;

import com.example.microgrid.energy.dto.SalesOrderRequest;
import com.example.microgrid.energy.dto.SalesOrderResponse;
import com.example.microgrid.energy.entity.SalesOrder;
import com.example.microgrid.energy.entity.SalesOrderStatus;
import com.example.microgrid.energy.entity.SolarNode;
import com.example.microgrid.energy.repository.SalesOrderRepository;
import com.example.microgrid.energy.repository.SolarNodeRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class SalesOrderService {

    private final SalesOrderRepository orderRepository;
    private final SolarNodeRepository nodeRepository;

    public SalesOrderService(
            SalesOrderRepository orderRepository,
            SolarNodeRepository nodeRepository) {

        this.orderRepository = orderRepository;
        this.nodeRepository = nodeRepository;
    }

    public SalesOrderResponse createOrder(
            SalesOrderRequest request) {

        if (request.getOrderNumber() == null
                || request.getOrderNumber().isBlank()) {

            throw new RuntimeException(
                    "Order number is required");
        }

        if (request.getConsumptionKwh() == null
                || request.getConsumptionKwh() <= 0) {

            throw new RuntimeException(
                    "Consumption kWh must be greater than zero");
        }

        if (request.getRatePerKwh() == null
                || request.getRatePerKwh() <= 0) {

            throw new RuntimeException(
                    "Rate per kWh must be greater than zero");
        }

        if (orderRepository
                .findByOrderNumber(request.getOrderNumber())
                .isPresent()) {

            throw new RuntimeException(
                    "Sales order number already exists");
        }

        SolarNode node = nodeRepository
                .findById(request.getSolarNodeId())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Solar node not found"));

        double totalAmount =
                request.getConsumptionKwh()
                        * request.getRatePerKwh();

        SalesOrder order = new SalesOrder(
                request.getOrderNumber(),
                node,
                request.getConsumptionKwh(),
                request.getRatePerKwh(),
                totalAmount,
                SalesOrderStatus.CONFIRMED,
                LocalDateTime.now()
        );

        return convertToResponse(
                orderRepository.save(order));
    }

    public SalesOrderResponse getOrder(Long id) {

        SalesOrder order = orderRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Sales order not found"));

        return convertToResponse(order);
    }

    public List<SalesOrderResponse> getAllOrders() {

        return orderRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    private SalesOrderResponse convertToResponse(
            SalesOrder order) {

        return new SalesOrderResponse(
                order.getId(),
                order.getOrderNumber(),
                order.getSolarNode().getId(),
                order.getConsumptionKwh(),
                order.getRatePerKwh(),
                order.getTotalAmount(),
                order.getStatus(),
                order.getOrderDate()
        );
    }
}