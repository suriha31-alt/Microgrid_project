package com.example.microgrid.energy.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.SmartMeterRequest;
import com.example.microgrid.energy.dto.SmartMeterResponse;
import com.example.microgrid.energy.entity.MeterStatus;
import com.example.microgrid.energy.entity.SmartMeter;
import com.example.microgrid.energy.entity.SolarNode;
import com.example.microgrid.energy.repository.SmartMeterRepository;
import com.example.microgrid.energy.repository.SolarNodeRepository;

@Service
public class SmartMeterService {

    private final SmartMeterRepository meterRepository;
    private final SolarNodeRepository nodeRepository;

    public SmartMeterService(
            SmartMeterRepository meterRepository,
            SolarNodeRepository nodeRepository) {

        this.meterRepository = meterRepository;
        this.nodeRepository = nodeRepository;
    }

    public SmartMeterResponse createMeter(
            SmartMeterRequest request) {

        if (meterRepository
                .findByMeterNumber(request.getMeterNumber())
                .isPresent()) {

            throw new RuntimeException(
                    "Meter number already exists");
        }

        SolarNode solarNode = nodeRepository
                .findById(request.getSolarNodeId())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Solar node not found"));

        MeterStatus status = request.getStatus();

        if (status == null) {
            status = MeterStatus.ACTIVE;
        }

        SmartMeter meter = new SmartMeter(
                request.getMeterNumber(),
                request.getMeterType(),
                solarNode,
                status
        );

        SmartMeter savedMeter =
                meterRepository.save(meter);

        return convertToResponse(savedMeter);
    }

    public List<SmartMeterResponse> getAllMeters() {

        return meterRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    public SmartMeterResponse getMeterById(Long id) {

        SmartMeter meter = meterRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Smart meter not found"));

        return convertToResponse(meter);
    }

    private SmartMeterResponse convertToResponse(
            SmartMeter meter) {

        return new SmartMeterResponse(
                meter.getId(),
                meter.getMeterNumber(),
                meter.getMeterType(),
                meter.getSolarNode().getId(),
                meter.getStatus()
        );
    }
}