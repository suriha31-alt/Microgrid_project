package com.example.microgrid.energy.dto;

import com.example.microgrid.energy.entity.SalesOrderStatus;

import java.time.LocalDateTime;

public class SalesOrderResponse {

    private final Long id;
    private final String orderNumber;
    private final Long solarNodeId;
    private final Double consumptionKwh;
    private final Double ratePerKwh;
    private final Double totalAmount;
    private final SalesOrderStatus status;
    private final LocalDateTime orderDate;

    public SalesOrderResponse(
            Long id,
            String orderNumber,
            Long solarNodeId,
            Double consumptionKwh,
            Double ratePerKwh,
            Double totalAmount,
            SalesOrderStatus status,
            LocalDateTime orderDate) {

        this.id = id;
        this.orderNumber = orderNumber;
        this.solarNodeId = solarNodeId;
        this.consumptionKwh = consumptionKwh;
        this.ratePerKwh = ratePerKwh;
        this.totalAmount = totalAmount;
        this.status = status;
        this.orderDate = orderDate;
    }

    public Long getId() {
        return id;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public Long getSolarNodeId() {
        return solarNodeId;
    }

    public Double getConsumptionKwh() {
        return consumptionKwh;
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public SalesOrderStatus getStatus() {
        return status;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }
}