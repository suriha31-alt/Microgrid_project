package com.example.microgrid.energy.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "energy_telemetry")
public class EnergyTelemetry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "meter_id", nullable = false)
    private SmartMeter meter;

    @Column(nullable = false)
    private LocalDateTime timestamp;

    @Column(nullable = false)
    private Double generationKwh;

    @Column(nullable = false)
    private Double consumptionKwh;

    @Column(nullable = false)
    private Double batteryChargeKwh;

    @Column(nullable = false)
    private Double surplusKwh;

    @Column(nullable = false)
    private Double deficitKwh;

    public EnergyTelemetry() {
    }

    public EnergyTelemetry(
            SmartMeter meter,
            LocalDateTime timestamp,
            Double generationKwh,
            Double consumptionKwh,
            Double batteryChargeKwh,
            Double surplusKwh,
            Double deficitKwh) {

        this.meter = meter;
        this.timestamp = timestamp;
        this.generationKwh = generationKwh;
        this.consumptionKwh = consumptionKwh;
        this.batteryChargeKwh = batteryChargeKwh;
        this.surplusKwh = surplusKwh;
        this.deficitKwh = deficitKwh;
    }

    public Long getId() {
        return id;
    }

    public SmartMeter getMeter() {
        return meter;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public Double getGenerationKwh() {
        return generationKwh;
    }

    public Double getConsumptionKwh() {
        return consumptionKwh;
    }

    public Double getBatteryChargeKwh() {
        return batteryChargeKwh;
    }

    public Double getSurplusKwh() {
        return surplusKwh;
    }

    public Double getDeficitKwh() {
        return deficitKwh;
    }
}