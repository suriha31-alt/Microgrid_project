package com.example.microgrid.energy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.TelemetryRequest;
import com.example.microgrid.energy.dto.TelemetryResponse;
import com.example.microgrid.energy.service.EnergyTelemetryService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/energy/telemetry")
public class EnergyTelemetryController {

    private final EnergyTelemetryService service;

    public EnergyTelemetryController(
            EnergyTelemetryService service) {

        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TelemetryResponse recordTelemetry(
            @Valid @RequestBody TelemetryRequest request) {

        return service.recordTelemetry(request);
    }

    @GetMapping
    public List<TelemetryResponse> getAllTelemetry() {

        return service.getAllTelemetry();
    }

    @GetMapping("/meter/{meterId}")
    public List<TelemetryResponse> getTelemetryByMeter(
            @PathVariable Long meterId) {

        return service.getTelemetryByMeter(meterId);
    }
}