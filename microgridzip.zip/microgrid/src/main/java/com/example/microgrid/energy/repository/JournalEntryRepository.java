package com.example.microgrid.energy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.JournalEntry;

public interface JournalEntryRepository
        extends JpaRepository<JournalEntry, Long> {

    List<JournalEntry> findByJournalId(Long journalId);

    List<JournalEntry> findByAccountId(Long accountId);

    List<JournalEntry> findByReferenceNumber(
            String referenceNumber);
}