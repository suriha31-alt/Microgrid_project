package com.example.microgrid.energy.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.PaymentRequest;
import com.example.microgrid.energy.dto.PaymentResponse;
import com.example.microgrid.energy.entity.Payment;
import com.example.microgrid.energy.repository.PaymentRepository;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;

    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    public PaymentResponse createPayment(PaymentRequest request) {

        if (paymentRepository.existsByPaymentNumber(
                request.getPaymentNumber())) {

            throw new RuntimeException(
                    "Payment number already exists");
        }

        if (request.getAmount() == null ||
                request.getAmount() <= 0) {

            throw new RuntimeException(
                    "Payment amount must be greater than zero");
        }

        Payment payment = new Payment(
                request.getPaymentNumber(),
                request.getInvoiceId(),
                request.getAmount(),
                request.getPaymentMethod(),
                "COMPLETED",
                LocalDateTime.now()
        );

        return convertToResponse(
                paymentRepository.save(payment));
    }

    public PaymentResponse getPayment(Long id) {

        Payment payment = paymentRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Payment not found"));

        return convertToResponse(payment);
    }

    public List<PaymentResponse> getAllPayments() {

        return paymentRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    private PaymentResponse convertToResponse(Payment payment) {

        return new PaymentResponse(
                payment.getId(),
                payment.getPaymentNumber(),
                payment.getInvoiceId(),
                payment.getAmount(),
                payment.getPaymentMethod(),
                payment.getStatus(),
                payment.getPaymentDate()
        );
    }
}