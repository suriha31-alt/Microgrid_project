package com.example.microgrid.energy.controller;

import com.example.microgrid.energy.dto.CustomerInvoiceResponse;
import com.example.microgrid.energy.service.CustomerInvoiceService;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/energy/invoices")
public class CustomerInvoiceController {

    private final CustomerInvoiceService service;

    public CustomerInvoiceController(
            CustomerInvoiceService service) {

        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CustomerInvoiceResponse createInvoice(
            @RequestParam Long salesOrderId,
            @RequestParam String invoiceNumber) {

        return service.createInvoice(
                salesOrderId,
                invoiceNumber);
    }

    @GetMapping("/{id}")
    public CustomerInvoiceResponse getInvoice(
            @PathVariable Long id) {

        return service.getInvoice(id);
    }

    @GetMapping
    public List<CustomerInvoiceResponse> getAllInvoices() {

        return service.getAllInvoices();
    }
}