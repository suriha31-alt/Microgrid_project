package com.example.microgrid.energy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.TariffRequest;
import com.example.microgrid.energy.dto.TariffResponse;
import com.example.microgrid.energy.entity.TariffType;
import com.example.microgrid.energy.service.TariffService;

@RestController
@RequestMapping("/api/energy/tariffs")
public class TariffController {

    private final TariffService service;

    public TariffController(TariffService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TariffResponse createTariff(
            @RequestBody TariffRequest request) {

        return service.createTariff(request);
    }

    @GetMapping
    public List<TariffResponse> getAllTariffs() {

        return service.getAllTariffs();
    }

    @GetMapping("/active/{type}")
    public TariffResponse getActiveTariff(
            @PathVariable TariffType type) {

        return service.getActiveTariff(type);
    }

    @GetMapping("/calculate")
    public Double calculateFeedInTariff(
            @RequestParam Double generatedKwh,
            @RequestParam Double demandKwh) {

        return service.calculateFeedInTariff(
                generatedKwh,
                demandKwh);
    }
}