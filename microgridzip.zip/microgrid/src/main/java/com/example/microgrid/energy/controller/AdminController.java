package com.example.microgrid.energy.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.example.microgrid.energy.dto.AdminLoginRequest;
import com.example.microgrid.energy.dto.AdminLoginResponse;
import com.example.microgrid.energy.entity.Admin;
import com.example.microgrid.energy.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService adminService;

    public AdminController(AdminService adminService) {
        this.adminService = adminService;
    }

    @PostMapping("/create")
    @ResponseStatus(HttpStatus.CREATED)
    public Admin createAdmin(
            @RequestParam String username,
            @RequestParam String password) {

        return adminService.createAdmin(
                username,
                password
        );
    }

    @PostMapping("/login")
    public AdminLoginResponse login(
            @RequestBody AdminLoginRequest request) {

        return adminService.login(request);
    }
}