package com.example.microgrid.energy.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "solar_nodes")
public class SolarNode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nodeCode;

    @Column(nullable = false)
    private String nodeName;

    @Column(nullable = false)
    private Double capacityKw;

    private String location;

    @Enumerated(EnumType.STRING)
    private NodeStatus status;

    public SolarNode() {
    }

    public SolarNode(String nodeCode, String nodeName,
                     Double capacityKw, String location,
                     NodeStatus status) {
        this.nodeCode = nodeCode;
        this.nodeName = nodeName;
        this.capacityKw = capacityKw;
        this.location = location;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public String getNodeCode() {
        return nodeCode;
    }

    public void setNodeCode(String nodeCode) {
        this.nodeCode = nodeCode;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public Double getCapacityKw() {
        return capacityKw;
    }

    public void setCapacityKw(Double capacityKw) {
        this.capacityKw = capacityKw;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public NodeStatus getStatus() {
        return status;
    }

    public void setStatus(NodeStatus status) {
        this.status = status;
    }
}