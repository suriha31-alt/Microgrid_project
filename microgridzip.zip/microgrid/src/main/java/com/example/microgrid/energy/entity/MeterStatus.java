package com.example.microgrid.energy.entity;

public enum MeterStatus {
    ACTIVE,
    INACTIVE,
    FAULTY,
    MAINTENANCE
}