package com.example.microgrid.energy.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "sales_orders")
public class SalesOrder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String orderNumber;

    @ManyToOne(optional = false)
    @JoinColumn(name = "solar_node_id")
    private SolarNode solarNode;

    @Column(nullable = false)
    private Double consumptionKwh;

    @Column(nullable = false)
    private Double ratePerKwh;

    @Column(nullable = false)
    private Double totalAmount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SalesOrderStatus status;

    @Column(nullable = false)
    private LocalDateTime orderDate;

    public SalesOrder() {
    }

    public SalesOrder(
            String orderNumber,
            SolarNode solarNode,
            Double consumptionKwh,
            Double ratePerKwh,
            Double totalAmount,
            SalesOrderStatus status,
            LocalDateTime orderDate) {

        this.orderNumber = orderNumber;
        this.solarNode = solarNode;
        this.consumptionKwh = consumptionKwh;
        this.ratePerKwh = ratePerKwh;
        this.totalAmount = totalAmount;
        this.status = status;
        this.orderDate = orderDate;
    }

    public Long getId() {
        return id;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public SolarNode getSolarNode() {
        return solarNode;
    }

    public Double getConsumptionKwh() {
        return consumptionKwh;
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public SalesOrderStatus getStatus() {
        return status;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setStatus(SalesOrderStatus status) {
        this.status = status;
    }
}