package com.example.microgrid.energy.dto;

import com.example.microgrid.energy.entity.MeterStatus;

public class SmartMeterResponse {

    private Long id;
    private String meterNumber;
    private String meterType;
    private Long solarNodeId;
    private MeterStatus status;

    public SmartMeterResponse() {
    }

    public SmartMeterResponse(
            Long id,
            String meterNumber,
            String meterType,
            Long solarNodeId,
            MeterStatus status) {

        this.id = id;
        this.meterNumber = meterNumber;
        this.meterType = meterType;
        this.solarNodeId = solarNodeId;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public String getMeterType() {
        return meterType;
    }

    public Long getSolarNodeId() {
        return solarNodeId;
    }

    public MeterStatus getStatus() {
        return status;
    }
}