package com.example.microgrid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicrogridApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicrogridApplication.class, args);
	}

}
