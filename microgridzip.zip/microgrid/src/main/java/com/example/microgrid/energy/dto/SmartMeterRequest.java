package com.example.microgrid.energy.dto;

import com.example.microgrid.energy.entity.MeterStatus;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class SmartMeterRequest {

    @NotBlank(message = "Meter number is required")
    private String meterNumber;

    @NotBlank(message = "Meter type is required")
    private String meterType;

    @NotNull(message = "Solar node ID is required")
    private Long solarNodeId;

    private MeterStatus status;

    public SmartMeterRequest() {
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }

    public String getMeterType() {
        return meterType;
    }

    public void setMeterType(String meterType) {
        this.meterType = meterType;
    }

    public Long getSolarNodeId() {
        return solarNodeId;
    }

    public void setSolarNodeId(Long solarNodeId) {
        this.solarNodeId = solarNodeId;
    }

    public MeterStatus getStatus() {
        return status;
    }

    public void setStatus(MeterStatus status) {
        this.status = status;
    }
}