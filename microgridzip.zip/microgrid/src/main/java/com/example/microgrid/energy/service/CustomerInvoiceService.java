package com.example.microgrid.energy.service;

import com.example.microgrid.energy.dto.CustomerInvoiceResponse;
import com.example.microgrid.energy.entity.CustomerInvoice;
import com.example.microgrid.energy.entity.CustomerInvoiceStatus;
import com.example.microgrid.energy.entity.SalesOrder;
import com.example.microgrid.energy.entity.SalesOrderStatus;
import com.example.microgrid.energy.repository.CustomerInvoiceRepository;
import com.example.microgrid.energy.repository.SalesOrderRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CustomerInvoiceService {

    private final CustomerInvoiceRepository invoiceRepository;
    private final SalesOrderRepository orderRepository;

    public CustomerInvoiceService(
            CustomerInvoiceRepository invoiceRepository,
            SalesOrderRepository orderRepository) {

        this.invoiceRepository = invoiceRepository;
        this.orderRepository = orderRepository;
    }

    public CustomerInvoiceResponse createInvoice(
            Long salesOrderId,
            String invoiceNumber) {

        if (invoiceNumber == null
                || invoiceNumber.isBlank()) {

            throw new RuntimeException(
                    "Invoice number is required");
        }

        if (invoiceRepository
                .findByInvoiceNumber(invoiceNumber)
                .isPresent()) {

            throw new RuntimeException(
                    "Invoice number already exists");
        }

        if (invoiceRepository
                .findBySalesOrderId(salesOrderId)
                .isPresent()) {

            throw new RuntimeException(
                    "Invoice already exists for this sales order");
        }

        SalesOrder order = orderRepository
                .findById(salesOrderId)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Sales order not found"));

        CustomerInvoice invoice =
                new CustomerInvoice(
                        invoiceNumber,
                        order,
                        order.getTotalAmount(),
                        0.0,
                        CustomerInvoiceStatus.UNPAID,
                        LocalDateTime.now()
                );

        order.setStatus(SalesOrderStatus.INVOICED);

        orderRepository.save(order);

        return convertToResponse(
                invoiceRepository.save(invoice));
    }

    public CustomerInvoiceResponse getInvoice(
            Long invoiceId) {

        CustomerInvoice invoice =
                invoiceRepository
                        .findById(invoiceId)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Customer invoice not found"));

        return convertToResponse(invoice);
    }

    public List<CustomerInvoiceResponse> getAllInvoices() {

        return invoiceRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    private CustomerInvoiceResponse convertToResponse(
            CustomerInvoice invoice) {

        double outstanding =
                invoice.getInvoiceAmount()
                        - invoice.getPaidAmount();

        return new CustomerInvoiceResponse(
                invoice.getId(),
                invoice.getInvoiceNumber(),
                invoice.getSalesOrder().getId(),
                invoice.getInvoiceAmount(),
                invoice.getPaidAmount(),
                outstanding,
                invoice.getStatus(),
                invoice.getInvoiceDate()
        );
    }
}