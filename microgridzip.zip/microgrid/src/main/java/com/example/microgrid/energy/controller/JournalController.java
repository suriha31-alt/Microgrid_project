package com.example.microgrid.energy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.JournalEntryResponse;
import com.example.microgrid.energy.dto.JournalRequest;
import com.example.microgrid.energy.service.JournalService;

@RestController
@RequestMapping("/api/energy/journals")
public class JournalController {

    private final JournalService service;

    public JournalController(JournalService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public List<JournalEntryResponse> createJournal(
            @RequestBody JournalRequest request) {

        return service.createJournal(request);
    }

    @GetMapping("/{journalId}/entries")
    public List<JournalEntryResponse> getJournalEntries(
            @PathVariable Long journalId) {

        return service.getJournalEntries(journalId);
    }

    @GetMapping("/account/{accountId}")
    public List<JournalEntryResponse> getAccountEntries(
            @PathVariable Long accountId) {

        return service.getAccountEntries(accountId);
    }

    @GetMapping("/reference/{referenceNumber}")
    public List<JournalEntryResponse> getEntriesByReference(
            @PathVariable String referenceNumber) {

        return service.getEntriesByReference(
                referenceNumber);
    }
}