package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class ProductResponse {

    private final Long id;
    private final String productCode;
    private final String productName;
    private final String type;
    private final String unit;
    private final Double price;
    private final String description;
    private final Boolean active;
    private final LocalDateTime createdAt;

    public ProductResponse(
            Long id,
            String productCode,
            String productName,
            String type,
            String unit,
            Double price,
            String description,
            Boolean active,
            LocalDateTime createdAt) {

        this.id = id;
        this.productCode = productCode;
        this.productName = productName;
        this.type = type;
        this.unit = unit;
        this.price = price;
        this.description = description;
        this.active = active;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getProductCode() {
        return productCode;
    }

    public String getProductName() {
        return productName;
    }

    public String getType() {
        return type;
    }

    public String getUnit() {
        return unit;
    }

    public Double getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    public Boolean getActive() {
        return active;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}