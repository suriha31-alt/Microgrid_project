package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class EnergyTradeResponse {

    private final Long tradeId;
    private final Long sellerNodeId;
    private final Long buyerNodeId;
    private final Double energyKwh;
    private final Double pricePerKwh;
    private final Double totalAmount;
    private final String status;
    private final LocalDateTime tradeTime;

    public EnergyTradeResponse(
            Long tradeId,
            Long sellerNodeId,
            Long buyerNodeId,
            Double energyKwh,
            Double pricePerKwh,
            Double totalAmount,
            String status,
            LocalDateTime tradeTime) {

        this.tradeId = tradeId;
        this.sellerNodeId = sellerNodeId;
        this.buyerNodeId = buyerNodeId;
        this.energyKwh = energyKwh;
        this.pricePerKwh = pricePerKwh;
        this.totalAmount = totalAmount;
        this.status = status;
        this.tradeTime = tradeTime;
    }

    public Long getTradeId() {
        return tradeId;
    }

    public Long getSellerNodeId() {
        return sellerNodeId;
    }

    public Long getBuyerNodeId() {
        return buyerNodeId;
    }

    public Double getEnergyKwh() {
        return energyKwh;
    }

    public Double getPricePerKwh() {
        return pricePerKwh;
    }

    public Double getTotalAmount() {
        return totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public LocalDateTime getTradeTime() {
        return tradeTime;
    }
}