package com.example.microgrid.energy.entity;

public enum SalesOrderStatus {

    DRAFT,
    CONFIRMED,
    INVOICED,
    CANCELLED
}