package com.example.microgrid.energy.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.EnergyTelemetry;

public interface EnergyTelemetryRepository
        extends JpaRepository<EnergyTelemetry, Long> {

    List<EnergyTelemetry> findByMeterId(Long meterId);
}