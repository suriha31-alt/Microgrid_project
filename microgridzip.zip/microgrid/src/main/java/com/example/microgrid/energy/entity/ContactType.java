package com.example.microgrid.energy.entity;

public enum ContactType {

    PROSUMER,
    CONSUMER,
    EQUIPMENT_PROVIDER
}