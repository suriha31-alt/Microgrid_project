package com.example.microgrid.energy.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "customer_invoices")
public class CustomerInvoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String invoiceNumber;

    @OneToOne(optional = false)
    @JoinColumn(name = "sales_order_id", unique = true)
    private SalesOrder salesOrder;

    @Column(nullable = false)
    private Double invoiceAmount;

    @Column(nullable = false)
    private Double paidAmount;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CustomerInvoiceStatus status;

    @Column(nullable = false)
    private LocalDateTime invoiceDate;

    public CustomerInvoice() {
    }

    public CustomerInvoice(
            String invoiceNumber,
            SalesOrder salesOrder,
            Double invoiceAmount,
            Double paidAmount,
            CustomerInvoiceStatus status,
            LocalDateTime invoiceDate) {

        this.invoiceNumber = invoiceNumber;
        this.salesOrder = salesOrder;
        this.invoiceAmount = invoiceAmount;
        this.paidAmount = paidAmount;
        this.status = status;
        this.invoiceDate = invoiceDate;
    }

    public Long getId() {
        return id;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public SalesOrder getSalesOrder() {
        return salesOrder;
    }

    public Double getInvoiceAmount() {
        return invoiceAmount;
    }

    public Double getPaidAmount() {
        return paidAmount;
    }

    public CustomerInvoiceStatus getStatus() {
        return status;
    }

    public LocalDateTime getInvoiceDate() {
        return invoiceDate;
    }

    public void setPaidAmount(Double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public void setStatus(CustomerInvoiceStatus status) {
        this.status = status;
    }
}