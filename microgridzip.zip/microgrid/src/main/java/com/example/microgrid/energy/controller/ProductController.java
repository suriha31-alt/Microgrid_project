package com.example.microgrid.energy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.ProductRequest;
import com.example.microgrid.energy.dto.ProductResponse;
import com.example.microgrid.energy.service.ProductService;

@RestController
@RequestMapping("/api/energy/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ProductResponse createProduct(
            @RequestBody ProductRequest request) {

        return service.createProduct(request);
    }

    @GetMapping
    public List<ProductResponse> getAllProducts() {
        return service.getAllProducts();
    }

    @GetMapping("/{id}")
    public ProductResponse getProduct(
            @PathVariable Long id) {

        return service.getProduct(id);
    }

    @GetMapping("/type/{type}")
    public List<ProductResponse> getProductsByType(
            @PathVariable String type) {

        return service.getProductsByType(type);
    }

    @PutMapping("/{id}/deactivate")
    public ProductResponse deactivateProduct(
            @PathVariable Long id) {

        return service.deactivateProduct(id);
    }
}