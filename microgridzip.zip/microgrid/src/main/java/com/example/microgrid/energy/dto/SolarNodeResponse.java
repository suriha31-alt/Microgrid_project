
package com.example.microgrid.energy.dto;

import com.example.microgrid.energy.entity.NodeStatus;

public class SolarNodeResponse {

    private Long id;
    private String nodeCode;
    private String nodeName;
    private Double capacityKw;
    private String location;
    private NodeStatus status;

    public SolarNodeResponse() {
    }

    public SolarNodeResponse(
            Long id,
            String nodeCode,
            String nodeName,
            Double capacityKw,
            String location,
            NodeStatus status) {

        this.id = id;
        this.nodeCode = nodeCode;
        this.nodeName = nodeName;
        this.capacityKw = capacityKw;
        this.location = location;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public String getNodeCode() {
        return nodeCode;
    }

    public String getNodeName() {
        return nodeName;
    }

    public Double getCapacityKw() {
        return capacityKw;
    }

    public String getLocation() {
        return location;
    }

    public NodeStatus getStatus() {
        return status;
    }
}