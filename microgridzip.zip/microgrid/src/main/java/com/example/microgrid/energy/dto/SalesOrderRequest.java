package com.example.microgrid.energy.dto;

public class SalesOrderRequest {

    private String orderNumber;
    private Long solarNodeId;
    private Double consumptionKwh;
    private Double ratePerKwh;

    public SalesOrderRequest() {
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Long getSolarNodeId() {
        return solarNodeId;
    }

    public void setSolarNodeId(Long solarNodeId) {
        this.solarNodeId = solarNodeId;
    }

    public Double getConsumptionKwh() {
        return consumptionKwh;
    }

    public void setConsumptionKwh(Double consumptionKwh) {
        this.consumptionKwh = consumptionKwh;
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public void setRatePerKwh(Double ratePerKwh) {
        this.ratePerKwh = ratePerKwh;
    }
}