package com.example.microgrid.energy.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.microgrid.energy.entity.EnergyWallet;

public interface EnergyWalletRepository
        extends JpaRepository<EnergyWallet, Long> {

    Optional<EnergyWallet> findBySolarNodeId(Long solarNodeId);
}