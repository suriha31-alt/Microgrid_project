package com.example.microgrid.energy.entity;

public enum ProductType {

    GOODS,
    SERVICE
}