package com.example.microgrid.energy.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.microgrid.energy.dto.TariffRequest;
import com.example.microgrid.energy.dto.TariffResponse;
import com.example.microgrid.energy.entity.Tariff;
import com.example.microgrid.energy.entity.TariffType;
import com.example.microgrid.energy.repository.TariffRepository;

@Service
public class TariffService {

    private final TariffRepository tariffRepository;

    public TariffService(TariffRepository tariffRepository) {
        this.tariffRepository = tariffRepository;
    }

    public TariffResponse createTariff(
            TariffRequest request) {

        if (request.getRatePerKwh() == null
                || request.getRatePerKwh() < 0) {

            throw new RuntimeException(
                    "Rate per kWh must be valid");
        }

        if (request.getMinimumRate() == null
                || request.getMaximumRate() == null) {

            throw new RuntimeException(
                    "Minimum and maximum rates are required");
        }

        if (request.getMinimumRate()
                > request.getMaximumRate()) {

            throw new RuntimeException(
                    "Minimum rate cannot exceed maximum rate");
        }

        Tariff tariff = new Tariff(
                request.getType(),
                request.getRatePerKwh(),
                request.getMinimumRate(),
                request.getMaximumRate(),
                true,
                LocalDateTime.now()
        );

        return convertToResponse(
                tariffRepository.save(tariff));
    }

    public TariffResponse getActiveTariff(
            TariffType type) {

        Tariff tariff = tariffRepository
                .findByTypeAndActiveTrue(type)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Active tariff not found"));

        return convertToResponse(tariff);
    }

    public Double calculateFeedInTariff(
            Double generatedKwh,
            Double demandKwh) {

        Tariff tariff = tariffRepository
                .findByTypeAndActiveTrue(
                        TariffType.FEED_IN)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Feed-in tariff not configured"));

        if (generatedKwh == null || generatedKwh <= 0) {
            throw new RuntimeException(
                    "Generated kWh must be greater than zero");
        }

        if (demandKwh == null || demandKwh < 0) {
            throw new RuntimeException(
                    "Demand kWh cannot be negative");
        }

        double rate = tariff.getRatePerKwh();

        /*
         * Higher demand increases the feed-in rate.
         * Lower demand keeps the base rate.
         */
        if (demandKwh > generatedKwh) {
            rate = rate * 1.10;
        }

        if (rate < tariff.getMinimumRate()) {
            rate = tariff.getMinimumRate();
        }

        if (rate > tariff.getMaximumRate()) {
            rate = tariff.getMaximumRate();
        }

        return rate;
    }

    public List<TariffResponse> getAllTariffs() {

        return tariffRepository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    private TariffResponse convertToResponse(
            Tariff tariff) {

        return new TariffResponse(
                tariff.getId(),
                tariff.getType().name(),
                tariff.getRatePerKwh(),
                tariff.getMinimumRate(),
                tariff.getMaximumRate(),
                tariff.getActive(),
                tariff.getCreatedAt()
        );
    }
}