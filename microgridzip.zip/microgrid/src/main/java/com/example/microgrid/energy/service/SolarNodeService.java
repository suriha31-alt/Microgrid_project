package com.example.microgrid.energy.service;

import com.example.microgrid.energy.dto.SolarNodeRequest;
import com.example.microgrid.energy.dto.SolarNodeResponse;
import com.example.microgrid.energy.entity.NodeStatus;
import com.example.microgrid.energy.entity.SolarNode;
import com.example.microgrid.energy.repository.SolarNodeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SolarNodeService {

    private final SolarNodeRepository repository;

    public SolarNodeService(SolarNodeRepository repository) {
        this.repository = repository;
    }

    public SolarNodeResponse createNode(SolarNodeRequest request) {

        if (repository.findByNodeCode(request.getNodeCode()).isPresent()) {
            throw new RuntimeException("Node code already exists");
        }

        NodeStatus status = request.getStatus();

        if (status == null) {
            status = NodeStatus.ACTIVE;
        }

        SolarNode node = new SolarNode(
                request.getNodeCode(),
                request.getNodeName(),
                request.getCapacityKw(),
                request.getLocation(),
                status
        );

        SolarNode savedNode = repository.save(node);

        return convertToResponse(savedNode);
    }

    public List<SolarNodeResponse> getAllNodes() {

        return repository.findAll()
                .stream()
                .map(this::convertToResponse)
                .toList();
    }

    public SolarNodeResponse getNodeById(Long id) {

        SolarNode node = repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Solar node not found"));

        return convertToResponse(node);
    }

    private SolarNodeResponse convertToResponse(SolarNode node) {

        return new SolarNodeResponse(
                node.getId(),
                node.getNodeCode(),
                node.getNodeName(),
                node.getCapacityKw(),
                node.getLocation(),
                node.getStatus()
        );
    }
}