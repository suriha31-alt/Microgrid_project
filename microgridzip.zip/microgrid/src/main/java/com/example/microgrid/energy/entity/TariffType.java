package com.example.microgrid.energy.entity;

public enum TariffType {

    FEED_IN,
    CONSUMPTION
}