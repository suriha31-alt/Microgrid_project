package com.example.microgrid.energy.dto;

import com.example.microgrid.energy.entity.CustomerInvoiceStatus;

import java.time.LocalDateTime;

public class CustomerInvoiceResponse {

    private Long id;
    private String invoiceNumber;
    private Long salesOrderId;
    private Double invoiceAmount;
    private Double paidAmount;
    private Double outstandingAmount;
    private CustomerInvoiceStatus status;
    private LocalDateTime invoiceDate;

    public CustomerInvoiceResponse(
            Long id,
            String invoiceNumber,
            Long salesOrderId,
            Double invoiceAmount,
            Double paidAmount,
            Double outstandingAmount,
            CustomerInvoiceStatus status,
            LocalDateTime invoiceDate) {

        this.id = id;
        this.invoiceNumber = invoiceNumber;
        this.salesOrderId = salesOrderId;
        this.invoiceAmount = invoiceAmount;
        this.paidAmount = paidAmount;
        this.outstandingAmount = outstandingAmount;
        this.status = status;
        this.invoiceDate = invoiceDate;
    }

    public Long getId() {
        return id;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public Long getSalesOrderId() {
        return salesOrderId;
    }

    public Double getInvoiceAmount() {
        return invoiceAmount;
    }

    public Double getPaidAmount() {
        return paidAmount;
    }

    public Double getOutstandingAmount() {
        return outstandingAmount;
    }

    public CustomerInvoiceStatus getStatus() {
        return status;
    }

    public LocalDateTime getInvoiceDate() {
        return invoiceDate;
    }
}