package com.example.microgrid.energy.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.microgrid.energy.dto.SmartMeterRequest;
import com.example.microgrid.energy.dto.SmartMeterResponse;
import com.example.microgrid.energy.service.SmartMeterService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/energy/meters")
public class SmartMeterController {

    private final SmartMeterService service;

    public SmartMeterController(
            SmartMeterService service) {

        this.service = service;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SmartMeterResponse createMeter(
            @Valid @RequestBody SmartMeterRequest request) {

        return service.createMeter(request);
    }

    @GetMapping
    public List<SmartMeterResponse> getAllMeters() {

        return service.getAllMeters();
    }

    @GetMapping("/{id}")
    public SmartMeterResponse getMeterById(
            @PathVariable Long id) {

        return service.getMeterById(id);
    }
}