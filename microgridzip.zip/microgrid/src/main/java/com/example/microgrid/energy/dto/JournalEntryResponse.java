
package com.example.microgrid.energy.dto;

import java.time.LocalDateTime;

public class JournalEntryResponse {

    private final Long id;

    private final Long journalId;
    private final String journalCode;

    private final Long accountId;
    private final String accountCode;
    private final String accountName;

    private final Double debit;
    private final Double credit;

    private final String description;
    private final String referenceNumber;
    private final LocalDateTime entryDate;

    public JournalEntryResponse(
            Long id,
            Long journalId,
            String journalCode,
            Long accountId,
            String accountCode,
            String accountName,
            Double debit,
            Double credit,
            String description,
            String referenceNumber,
            LocalDateTime entryDate) {

        this.id = id;
        this.journalId = journalId;
        this.journalCode = journalCode;
        this.accountId = accountId;
        this.accountCode = accountCode;
        this.accountName = accountName;
        this.debit = debit;
        this.credit = credit;
        this.description = description;
        this.referenceNumber = referenceNumber;
        this.entryDate = entryDate;
    }

    public Long getId() {
        return id;
    }

    public Long getJournalId() {
        return journalId;
    }

    public String getJournalCode() {
        return journalCode;
    }

    public Long getAccountId() {
        return accountId;
    }

    public String getAccountCode() {
        return accountCode;
    }

    public String getAccountName() {
        return accountName;
    }

    public Double getDebit() {
        return debit;
    }

    public Double getCredit() {
        return credit;
    }

    public String getDescription() {
        return description;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public LocalDateTime getEntryDate() {
        return entryDate;
    }
}
