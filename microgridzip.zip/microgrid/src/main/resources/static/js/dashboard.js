document.addEventListener("DOMContentLoaded", function () {

    console.log("Microgrid dashboard loaded");

    setupNotification();

    setupPeriodSelector();

});


/* =========================================================
   NOTIFICATION
   ========================================================= */

function setupNotification() {

    const notificationButton =
        document.querySelector(".notification");

    if (!notificationButton) {
        return;
    }

    notificationButton.addEventListener(
        "click",
        function () {

            alert("No new notifications.");

        }
    );

}


/* =========================================================
   PERIOD SELECTOR
   ========================================================= */

function setupPeriodSelector() {

    const selector =
        document.getElementById("periodSelector");

    if (!selector) {
        return;
    }

    selector.addEventListener(
        "change",
        function () {

            const period = selector.value;

            console.log(
                "Selected energy period:",
                period
            );

            /*
             * The chart is currently a visual dashboard
             * representation.
             *
             * Later we can connect this selector to your
             * telemetry backend and load real data for:
             *
             * today
             * week
             * month
             */

        }
    );

}


/* =========================================================
   DASHBOARD REFRESH
   ========================================================= */

function refreshDashboard() {

    console.log("Refreshing dashboard...");

    /*
     * This function is intentionally kept ready for
     * backend integration.
     *
     * Later we can load:
     *
     * solar generation
     * energy consumption
     * energy surplus
     * wallet balance
     * active solar nodes
     * recent trades
     */

}


/* =========================================================
   UTILITY
   ========================================================= */

function setDashboardValue(id, value) {

    const element =
        document.getElementById(id);

    if (element) {

        element.textContent = value;

    }

}